/** Automatically generated file. DO NOT MODIFY */
package com.example.ftp4j_demo2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}