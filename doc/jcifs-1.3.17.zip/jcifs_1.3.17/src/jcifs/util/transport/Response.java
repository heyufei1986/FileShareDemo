package jcifs.util.transport;

public abstract class Response {
    public long expiration;
    public boolean isReceived;
}
